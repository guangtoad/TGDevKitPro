package com.toad.devkit.common.log;

public enum TGLogLevel {

    TGLogLevelDebug(0),
    TGLogLevelInfo(1),
    TGLogLevelWarn(2),
    TGLogLevelError(3),
    TGLogLevelCrash(5);

    private int level;//第一个成员变量

    private TGLogLevel(int level) {
        this.level = (short)level;
    }

    public int getLevel() {
        return this.level;
    }

}