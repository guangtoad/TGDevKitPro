package com.toad.tool.StubIFServer.util;

import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import javax.servlet.ServletInputStream;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.util.Map;

public class HttpServletUilt {
    // 二进制读取
    static public byte[] readAsBytes(HttpServletRequest request){

        if (!"POST".equals(request.getMethod())){
            return null;
        }

        int len = request.getContentLength();
        if (len < 1){
            return null;
        }

        byte[] buffer = new byte[len];
        ServletInputStream in = null;

        try
        {
            in = request.getInputStream();
            in.read(buffer, 0, len);
            in.close();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            if (null != in)
            {
                try
                {
                    in.close();
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }
            }
        }
        return buffer;
    }
    static public ResponseEntity<String> createResponseEntity(int httpStatus, Map<String,String> resopnseHseaders, String resopnseMessage){
        HttpHeaders httpHeaders = new HttpHeaders();
        if (null != resopnseHseaders && resopnseHseaders.size() > 0){
            for (String key : resopnseHseaders.keySet()) {
                httpHeaders.add(key,resopnseHseaders.get(key));
            }
        }
        return ResponseEntity.status(httpStatus)
                .headers(httpHeaders)
                .body(resopnseMessage);
    }
}
