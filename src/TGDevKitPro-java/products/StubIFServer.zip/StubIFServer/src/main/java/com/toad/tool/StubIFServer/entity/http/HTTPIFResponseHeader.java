package com.toad.tool.StubIFServer.entity.http;

public class HTTPIFResponseHeader extends HTTPIFHeader{

}
