package com.toad.devkit.common.utils.encryption;

import org.apache.commons.codec.binary.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.Key;
import java.security.NoSuchAlgorithmException;

public class AESTest {

    private static final String key = "BB";
    private static final String initVector = "CC";

    public static String encrypt(String value) {

        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(Cipher.ENCRYPT_MODE, skeySpec, iv);

            byte[] encrypted = cipher.doFinal(value.getBytes());
            return Base64.encodeBase64String(encrypted);
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return null;
    }
    public static String decrypt(String encrypted) {
        try {
            IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
            SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");

            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
            cipher.init(Cipher.DECRYPT_MODE, skeySpec, iv);
            byte[] original = cipher.doFinal(Base64.decodeBase64(encrypted));

            return new String(original);
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return null;
    }


    public static String decrypt(String content, String key, String vi) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, BadPaddingException, IllegalBlockSizeException, UnsupportedEncodingException, UnsupportedEncodingException, InvalidAlgorithmParameterException {

//        System.out.println("content : " + content);
//        System.out.println("key : " + key);
//        System.out.println("vi : " + vi);
        //Key k = toKey(Base64.decodeBase64(key));
        Key k = toKey(key.getBytes());
        byte[] encoded = k.getEncoded();
        SecretKeySpec aes = new SecretKeySpec(encoded, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
        IvParameterSpec iv = new IvParameterSpec(vi.getBytes());
        cipher.init(Cipher.DECRYPT_MODE, aes, iv);

        byte[] bytes = cipher.doFinal(Base64.decodeBase64(content));

        return new String(bytes, "UTF-8");
    }

    public static String encrypt(String data, String key, String vi) throws NoSuchPaddingException, NoSuchAlgorithmException, InvalidKeyException, UnsupportedEncodingException, BadPaddingException, IllegalBlockSizeException, InvalidAlgorithmParameterException {

        //Key k = toKey(Base64.decodeBase64(key));
        Key k = toKey(key.getBytes());
        byte[] encoded = k.getEncoded();
        SecretKeySpec aes = new SecretKeySpec(encoded, "AES");
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
        IvParameterSpec iv = new IvParameterSpec(vi.getBytes());
        cipher.init(Cipher.ENCRYPT_MODE, aes, iv);
        byte[] bytes = cipher.doFinal(data.getBytes("UTF-8"));
        return Base64.encodeBase64String(bytes);
    }

    private static Key toKey(byte[] key){

        SecretKeySpec aes = new SecretKeySpec(key, "AES");
        return aes;
    }
    public static void test1(){
        try {
            String content = "7mv2MJPHj1o/rdar1I4i0Q==";
            String key = "sN1DEJAVZNf3OdM3";
            String vi = "GDHgt7hbKpsIR4b4";

            System.out.println("原文 : root");

            String e = encrypt("root", key, vi);
            System.out.println("密文 : " + e);
            String f = decrypt(e, key, vi);
            System.out.println("解密 : " + f);

        }
        catch (Exception e){
            System.out.println("E:\n" + e);
        }
    }
    public static void testRun(){
        test1();
//        String originalString = "AA";
//        System.out.println("Original String to encrypt - " + originalString);
//        String encryptedString = encrypt(originalString);
//        System.out.println("Encrypted String - " + encryptedString);
//        String decryptedString = decrypt(encryptedString);
//        System.out.println("After decryption - " + decryptedString);
        return;
    }

}
