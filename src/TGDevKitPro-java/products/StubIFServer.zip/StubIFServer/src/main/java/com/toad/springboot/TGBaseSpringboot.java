package com.toad.springboot;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.spi.LoggerRepository;
import org.apache.log4j.spi.RepositorySelector;

public class TGBaseSpringboot {

    private Logger logger;

    public Logger getLogger() {
        if (null == logger) {
            this.logger = LogManager.getLogger(this.getClass().getName());
        }
        return logger;
    }

    public void logInfo(String message){
        this.getLogger().info(message);
    }
    public void logDebug(String message){
        this.getLogger().debug(message);
    }
    public void logWarn(String message){
        this.getLogger().warn(message);
    }
    public void logError(String message){
        this.getLogger().error(message);
    }

}
