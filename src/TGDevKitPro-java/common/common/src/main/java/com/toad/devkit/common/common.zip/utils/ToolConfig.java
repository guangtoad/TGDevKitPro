package com.toad.devkit.common.utils;

public class ToolConfig {

    public String output;
    public boolean debug;
}
