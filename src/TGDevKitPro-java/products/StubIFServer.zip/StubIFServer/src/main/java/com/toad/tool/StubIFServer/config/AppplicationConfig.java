package com.toad.tool.StubIFServer.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:redisConfig.yaml")
public class AppplicationConfig {

}
