package com.toad.springboot;

public class TGBaseService extends TGBaseSpringboot {

}
