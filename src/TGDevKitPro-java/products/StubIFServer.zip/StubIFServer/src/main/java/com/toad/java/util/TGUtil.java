package com.toad.java.util;

public class TGUtil {

}
