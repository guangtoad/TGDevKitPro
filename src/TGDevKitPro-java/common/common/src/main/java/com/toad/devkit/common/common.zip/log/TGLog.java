package com.toad.devkit.common.log;

public class TGLog {

    static private TGLogLevel defaultLogLevel = TGLogLevel.TGLogLevelInfo;

    static public void  setDefaultLogLevel(TGLogLevel level){
        defaultLogLevel = level;
        loger.logLevel = defaultLogLevel;
    }

    static TGLogLevel getDefaultLogLevel(){
        return defaultLogLevel;
    }

    static TGLoger loger = new TGLoger(defaultLogLevel);


    static public void log(String msg,TGLogLevel level){
        loger.log(msg, level);
    }
    static public void Info(String msg) {
        log(msg, TGLogLevel.TGLogLevelInfo);
    }
    static public void Debug(String msg) {
        log(msg, TGLogLevel.TGLogLevelDebug);
    }
    static public void Warn(String msg) {
        log(msg, TGLogLevel.TGLogLevelWarn);
    }
    static public void Error(String msg) {
        log(msg, TGLogLevel.TGLogLevelError);
    }
    static public void Carsh(String msg){
        log(msg, TGLogLevel.TGLogLevelCrash);
    }

}
