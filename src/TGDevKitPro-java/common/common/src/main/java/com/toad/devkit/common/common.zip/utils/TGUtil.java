/*
 * *
 * @Description $description$
 * @Param $params$
 * @Return $returns$
 * @Author Mr.Ren
 * @Date $date$
 * @Time $time$
 * /
 */

package com.toad.devkit.common.utils;

/**
 * 工具类
 */
public class TGUtil {
    private static final String version = "0.0.0";

    /**
     * 获取版本号 version.
     *
     * @return 版本号
     */
    public static String getVersion() {
        return version;
    }
}
