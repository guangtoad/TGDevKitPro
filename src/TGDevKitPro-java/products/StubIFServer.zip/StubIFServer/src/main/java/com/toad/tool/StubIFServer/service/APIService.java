package com.toad.tool.StubIFServer.service;

import com.toad.tool.StubIFServer.StubException;
import com.toad.tool.StubIFServer.config.HTTPIFConfig;
import com.toad.tool.StubIFServer.entity.http.HTTPIFRequest;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Map;

@Service
public class APIService {

    @Resource
    protected HTTPIFConfig config;


//    public void asss(){
//        Hex.decod
//    }
    public HTTPIFRequest laodApi(String path, String type){
        HTTPIFRequest result = null;
        return result;
    }
//
//    public HTTPIFRequest loadApi(String path){
//        return loadApi(path,config.text_type);
//    }

    public void asdasd(){

    }

    public ResponseEntity<String> getResponse(String path, String paramString, Map<String,String> headers, String body) throws StubException {
        ResponseEntity<String> result = null;
        try {
//            String apiSettingString = readApiFile(path);

        }
//        catch (StubException e){
//            throw e;
//        }
        catch (Exception e){
            StackTraceElement stackTraceElement= e.getStackTrace()[0];// 得到异常棧的首个元素
            String message =  "API Setting Error " + "File="+stackTraceElement.getFileName()
                    + "Line="+stackTraceElement.getLineNumber()
                    + "Method="+stackTraceElement.getMethodName();
            throw StubException.ErrorException(message);
        }
        finally {

        }
        return result;
    }
}
