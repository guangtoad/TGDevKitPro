package com.toad.devkit.common.annotation;

public @interface TGAnnotation {
    boolean isRequired() default false;
}
