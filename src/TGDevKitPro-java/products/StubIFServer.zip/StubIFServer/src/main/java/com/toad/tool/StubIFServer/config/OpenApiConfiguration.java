package com.toad.tool.StubIFServer.config;

import com.github.xiaoymin.knife4j.spring.annotations.EnableKnife4j;
import io.swagger.v3.oas.annotations.ExternalDocumentation;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.boot.SpringBootConfiguration;
import springfox.documentation.oas.annotations.EnableOpenApi;

@OpenAPIDefinition(
        info = @Info(
                title = "Stub IF 服务",
                version = "1.0",
                description = "Swagger3使用演示",
                contact = @Contact(name = "toad", email = "guang_toad@outlook.com")
        ),
        security = @SecurityRequirement(name = "JWT"),
        externalDocs = @ExternalDocumentation(description = "参考文档",
                url = "https://github.com/swagger-api/swagger-core/wiki/Swagger-2.X---Annotations"
        )
)

@EnableOpenApi
@EnableKnife4j
@SpringBootConfiguration
public class OpenApiConfiguration {
    /**
     * @description:设置API文档信息
     * @author:hutao
     * @mail:hutao_2017@aliyun.com
     * @date:2022年3月16日 下午5:37:56
     */
//    private ApiInfo apiInfo() {
//        return new ApiInfoBuilder()
//                .title("XXXXXX项目字段API文档")
//                .version("3.0")
//                .description("该接口主要列举了数据的条件查询接口，以及表字段的详细介绍")
//                .build();
//    }
}
