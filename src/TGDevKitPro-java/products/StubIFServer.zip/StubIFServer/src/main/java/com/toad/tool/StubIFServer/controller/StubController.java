package com.toad.tool.StubIFServer.controller;

import com.toad.springboot.TGBaseController;

public class StubController extends TGBaseController {

}
