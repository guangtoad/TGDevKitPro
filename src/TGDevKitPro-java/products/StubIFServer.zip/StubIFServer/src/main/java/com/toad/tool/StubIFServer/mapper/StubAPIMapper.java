package com.toad.tool.StubIFServer.mapper;


import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Mapper
@Component
public interface StubAPIMapper {

}
