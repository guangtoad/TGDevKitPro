package com.toad.tool.StubIFServer.entity.http;

public class HTTPIFRequestConfig {

    public boolean formatCheck;

    public int formatStyle;

    public String formatSchema;
    public String formatSchemaPath;

    public String errorResponse;
    public String errorResponsePath;

    public boolean useExamples;

}
