package com.toad.devkit.web.StubIFServer.entity.http;

public class HTTPIFResponseHeader extends HTTPIFHeader{

}
