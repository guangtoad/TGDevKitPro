package com.toad.tool.StubIFServer.entity.http;

import java.util.List;
import java.util.Map;

public class HTTPIFExamples {

    public int formatStyle;
    public String examplesPath;
    public String fileExtension;
    public int exampleType;
    public int defStatus;
    public Map<String,String> defHeader;
    public List<String> header;
    public List<String> body;
    public List<String> parameters;



}
