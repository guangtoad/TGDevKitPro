package com.toad.tool.StubIFServer.Interface;

import com.toad.tool.StubIFServer.StubException;
import com.toad.tool.StubIFServer.entity.http.HTTPIFRequest;
import org.springframework.http.ResponseEntity;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface StubAPIServiceInterface {
    public ResponseEntity<String> getResponseEntity(HttpServletRequest request, HttpServletResponse response) throws StubException,Exception;

}
