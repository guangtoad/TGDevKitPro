/*
 * *
 * @Description $description$
 * @Param $params$
 * @Return $returns$
 * @Author Mr.Ren
 * @Date $date$
 * @Time $time$
 * /
 */

package com.toad.devkit.common.utils;


public class TGDebug {
    static public void logInfo(String msg){
        if (TGConfig.getInstance().isDebug) {
            System.out.println(msg);
        }
    }
}
