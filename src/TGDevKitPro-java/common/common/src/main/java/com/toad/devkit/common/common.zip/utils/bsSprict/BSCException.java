/*
 * *
 * @Description $description$
 * @Param $params$
 * @Return $returns$
 * @Author Mr.Ren
 * @Date $date$
 * @Time $time$
 * /
 */

package com.toad.devkit.common.utils.bsSprict;

public class BSCException extends  Exception{
    public BSCException(String s) {
        super(s);
    }
}
