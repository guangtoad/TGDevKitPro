package com.toad.tool.StubIFServer.entity.http;

public class HTTPIFResponseBody extends HTTPIFBody {
}
