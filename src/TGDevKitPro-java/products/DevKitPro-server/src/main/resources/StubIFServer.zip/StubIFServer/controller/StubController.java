package com.toad.devkit.web.StubIFServer.controller;


import com.toad.devkit.springframework.TGBaseController;

public class StubController extends TGBaseController {

}
