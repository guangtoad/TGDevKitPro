package com.toad.devkit.common.utils;

public class CommandProgess {
    private boolean showTitle = false;
    private int index = 0;
    private String finish;
    private String unFinish;
    private String title;

    // 进度条粒度
    private int PROGRESS_SIZE = 50;
    private int BITE = 2;

    private String getNChar(int num, char ch){
        StringBuilder builder = new StringBuilder();
        for(int i = 0; i < num; i++){
            builder.append(ch);
        }
        return builder.toString();
    }

    public CommandProgess(String title, int PROGRESS_SIZE,int bite){
        this.title = title;
        this.PROGRESS_SIZE = PROGRESS_SIZE;
        this.BITE = bite;
    }

    public CommandProgess(String title){
        this(title,50,2);
    }
    public CommandProgess(){
        this("Progress");
    }

    /**
     * @param progress 0~100
     * @throws InterruptedException
     */
    public void printProgress(int progress) throws InterruptedException {

        Math.min(100,Math.max(0 ,progress));
        if (!this.showTitle) {
            System.out.print(this.title + ":");
        }
    }

    /**
     * @param progress 0.00 ~ 1.00
     * @throws InterruptedException
     */
    public void printProgress(double progress){
        printProgress(Math.round(progress * 100));
    }

    /**
     * @param number
     * @param max
     */
    public void printProgress(long number, long max){
        printProgress(number/(Math.max(1, max) * 1.0));
    }

    public void printProgress() throws InterruptedException {
        System.out.print("Progress:");
        finish = getNChar(index / BITE, '█');
        unFinish = getNChar(PROGRESS_SIZE - index / BITE, '─');
        String target = String.format("%3d%%[%s%s]", index, finish, unFinish);
        System.out.print(target);
        while (index <= 100){
            finish = getNChar(index / BITE, '█');
            unFinish = getNChar(PROGRESS_SIZE - index / BITE, '─');
            target = String.format("%3d%%├%s%s┤", index, finish, unFinish);
            System.out.print(getNChar(PROGRESS_SIZE + 6, '\b'));
            System.out.print(target);
            Thread.sleep(150);
            index++;
        }
    }

}
