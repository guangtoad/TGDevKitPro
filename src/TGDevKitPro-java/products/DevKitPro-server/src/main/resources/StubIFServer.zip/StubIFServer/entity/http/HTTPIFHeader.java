package com.toad.devkit.web.StubIFServer.entity.http;

public class HTTPIFHeader extends HTTPIF {
}
