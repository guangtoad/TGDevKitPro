package com.toad.tool.StubIFServer.controller;

import com.toad.tool.StubIFServer.StubException;
import com.toad.tool.StubIFServer.service.StubAPIService;
import com.toad.tool.StubIFServer.util.HttpServletUilt;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class StubAPIController {

    @RequestMapping(value = "/api/**", produces = "application/json; charset=utf-8")
    public ResponseEntity<String> stubAPI(HttpServletRequest request, HttpServletResponse response){
        ResponseEntity<String> responseEntity = null;
        try {
            StubAPIService apiService = new StubAPIService();
            responseEntity = apiService.getResponseEntity(request, response);
            if (null == responseEntity) {
                throw StubException.ErrorException("Get Response iserror");
            }
        }
        catch (StubException e){
            responseEntity = ResponseEntity.status(e.httpStatus)
                    .body(e.getMessage());
        }
        catch (Exception e){
            responseEntity = HttpServletUilt.createResponseEntity(500, null, "Exception:\n"+ e);
        }

        return responseEntity;
    }

}
