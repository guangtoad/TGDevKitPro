package com.toad.devkit.common.log;


public class TGLoger {

    public TGLogLevel logLevel;

    TGLoger(TGLogLevel logLevel){
        this.logLevel = logLevel;
    }

    public void log(String msg, TGLogLevel level) {
        if (level.compareTo(this.logLevel) >= 0) {
//            TGCommandUtil.coutLine(msg);
        }
    }

    public void info(String msg) {
        log(msg, TGLogLevel.TGLogLevelInfo);
    }
    public void debug(String msg) {
        log(msg, TGLogLevel.TGLogLevelDebug);
    }
    public void warn(String msg) {
        log(msg, TGLogLevel.TGLogLevelWarn);
    }
    public void error(String msg) {
        log(msg, TGLogLevel.TGLogLevelError);
    }
    public void carsh(String msg){
        log(msg, TGLogLevel.TGLogLevelCrash);
    }

}
