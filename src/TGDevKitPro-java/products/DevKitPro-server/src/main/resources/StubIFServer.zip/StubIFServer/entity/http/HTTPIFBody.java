package com.toad.devkit.web.StubIFServer.entity.http;

public class HTTPIFBody extends HTTPIF {
}
