package com.toad.tool.StubIFServer.entity.http;

public class HTTPIFRequestBody extends HTTPIFBody {
}
