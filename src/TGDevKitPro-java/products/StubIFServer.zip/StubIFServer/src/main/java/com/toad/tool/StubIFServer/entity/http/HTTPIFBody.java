package com.toad.tool.StubIFServer.entity.http;

public class HTTPIFBody extends HTTPIF {
}
