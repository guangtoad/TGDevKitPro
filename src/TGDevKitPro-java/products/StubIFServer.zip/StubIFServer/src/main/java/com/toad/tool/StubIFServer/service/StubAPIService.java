package com.toad.tool.StubIFServer.service;

import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.JSONPath;
import com.google.gson.Gson;
import com.toad.java.util.TGFileUtil;
import com.toad.java.util.TGStringUtil;
import com.toad.springboot.TGBaseService;
import com.toad.tool.StubIFServer.Interface.StubAPIServiceInterface;
import com.toad.tool.StubIFServer.StubException;
import com.toad.tool.StubIFServer.config.HTTPIFConfig;
import com.toad.tool.StubIFServer.entity.http.HTTPIFRequest;
import com.toad.tool.StubIFServer.util.HttpServletUilt;
import org.apache.commons.io.FileUtils;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class StubAPIService  extends TGBaseService implements StubAPIServiceInterface {

    @Resource
    protected HTTPIFConfig config;
    HTTPIFRequest stubRequest = null;

    public File getDataFile(String path,String type){
        File result = null;
        return result;
    }





    public String getConext(String basePath ,String fullFilenameToAd ,String defaultConext) throws Exception{

        String result = defaultConext;

        if (null != fullFilenameToAd && fullFilenameToAd.length() > 0){

        }
        String filePath = "";
        File file = new File(filePath);

        if (file.isDirectory() || !file.exists()){
            result = FileUtils.readFileToString(file,this.config.encoding);
        }

        return result;
    }

    public File getStubRequestFile(String uri,String rootPath){
        File result = null;
        try {
            HTTPIFRequest reqeust = null;
            List<String> apis= Arrays.asList(uri.split("/"));
            if (apis.size() > 1) {
                for (int i =  apis.size() - 1; i > 0; i--){
                    String temp = TGStringUtil.join(apis, File.separator, 1, i);
                    System.out.println("temp:" + temp);
                    Path filePath = Paths.get(rootPath,temp + ".json");
                    File file= new File(filePath.toUri());
                    if (file.exists()){
                        result = file;
                        break;
                    }
                }
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }

    public HTTPIFRequest getStubRequest(String uri,String rootPath) throws Exception{

        HTTPIFRequest result = null;
        File file = this.getStubRequestFile(uri ,rootPath);
        if (null == file) {
            throw new StubException(404, "File not find:" + uri);
        }
        String txt = TGFileUtil.readFile(file);
        Gson gson = new Gson();
        HTTPIFRequest reqeust = null;
        reqeust = gson.fromJson(txt, HTTPIFRequest.class);

        try {
//            HTTPIFRequest reqeust = null;
//            List<String> apis= Arrays.asList(uri.split("/"));
//
//            if (apis.size() > 1){
//                for (int i =  apis.size() - 1; i > 0; i--){
//                    String temp = TGStringUtil.join(apis, File.separator, 1, i);
//                    System.out.println("temp:" + temp);
//                    Path filePath = Paths.get(rootPath,temp + ".json");
//                    File file= new File(filePath.toUri());
//                    if (file.exists()){
//                        String txt = TGFileUtil.readFile(file);
//                        Gson gson = new Gson();
//                        reqeust = gson.fromJson(txt, HTTPIFRequest.class);
//                        reqeust.filePath = filePath.toAbsolutePath().toString();
//                        break;
//                    }
//                }
//            }
            result = reqeust;
        }
//        catch (IOException e) {
//            e.printStackTrace();
//        }
        catch (Exception e){
            e.printStackTrace();
        }
        return result;
    }

    public ResponseEntity<String> getDefaultResponseEntity(){
        ResponseEntity<String> result = null;
//        getConext();
        if (null != stubRequest.defaultResposne.defResponseFilePath && stubRequest.defaultResposne.defResponseFilePath.length() > 1){

        }
        if (null == result && null != stubRequest.defaultResposne.bodyPath && stubRequest.defaultResposne.bodyPath.length() > 0) {

        }
        return HttpServletUilt.createResponseEntity(stubRequest.defaultResposne.status, stubRequest.defaultResposne.header, stubRequest.defaultResposne.body);
    }

    public ResponseEntity<String> getDefaultErrorResponseEntity(){
        ResponseEntity<String> result = null;
        return result;
    }

    @Override
    public ResponseEntity<String> getResponseEntity(HttpServletRequest request, HttpServletResponse response) throws Exception {

        ResponseEntity<String> result = null;

        try {

            if (null == request || null == response) {
                throw new StubException(500, "request or response is null");
            }

            String uri = request.getRequestURI();

            if (null != this.config.site_prefix && uri.startsWith(this.config.site_prefix)){
                uri = uri.replace(this.config.site_prefix,"");
            }

            if (uri.length() < 1) {
                throw StubException.NotFoundException("url error:" + uri);
            }

            HTTPIFRequest stubRequest = this.getStubRequest(uri, this.config.rootPath);

            if (stubRequest.config.useExamples){

            }

        }
        catch (StubException exception){
            throw exception;
        }
        catch (Exception exception){
            throw exception;
        }
        finally {

        }

        return result;
    }

}
