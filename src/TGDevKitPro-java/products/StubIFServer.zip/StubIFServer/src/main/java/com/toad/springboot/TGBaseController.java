package com.toad.springboot;

public class TGBaseController extends TGBaseSpringboot {

}
